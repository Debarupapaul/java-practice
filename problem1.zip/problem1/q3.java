public class Main {
    public static void main(String[] args) {
        MyClass obj = new MyClass();
        obj.publicV();   // accessible
        
        Main selfObj = new Main();
        selfObj.hereFunc();  // calling a function with this pointer
        hereFunc(); // calling without this
    }
    
    public static void hereFunc() {
        System.out.println("THis is an interneal function");
    }
}

class MyClass {
    public void publicV() {
        System.out.println("This is a public method");
    }
}