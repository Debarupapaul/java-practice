import java.util.*;

public class CollectionExample {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("Ramu");
        list.add("Gita");
        list.add("Shamu");

        for (String str : list) {
            System.out.println(str);
        }

        Set<String> set = new HashSet<>();
        set.add("Ramu");
        set.add("Gita");
        set.add("Shamu");
        Iterator<String> iterator = set.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        Map<Integer, String> map = new HashMap<>();
        map.put(1, "Ramu");
        map.put(2, "Gita");
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }
    }
}