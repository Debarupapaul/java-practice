public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		int varI = 10;
		double varD = varI; // implecit
		
		double varD1 = (double) varI;
		
		System.out.println(varD);
		System.out.println(varD1);
	}
}
