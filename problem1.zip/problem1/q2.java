public class Main {
    public static void main(String[] args) {
        MyClass obj = new MyClass();
        obj.publicV();   // accessible
        obj.protectedV(); // accessible within same package and subclass
        obj.defaultV();  // accessible within same package
        //obj.priv();  / gonna give error as not accessible
    }
}

class MyClass {
    public void publicV() {
        System.out.println("This is a public method");
    }

    protected void protectedV() {
        System.out.println("This is a protected method");
    }

    void defaultV() {
        System.out.println("This is a default method");
    }

    private void priv() {
        System.out.println("This is a private method");
    }
}