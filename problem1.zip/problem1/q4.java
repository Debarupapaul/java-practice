public class MyClass {
    int value;

    // Default constructor
    public MyClass() {
        value = 0;
        System.out.println("Default constructor called");
    }

    // Parameterized constructor
    public MyClass(int value) {
        this.value = value;
        System.out.println("Parameterized constructor called");
    }

    // Copy constructor
    public MyClass(MyClass obj) {
        this.value = obj.value;
        System.out.println("Copy constructor called");
    }

    public static void main(String[] args) {
        MyClass obj1 = new MyClass(); // calls the default constructor
        MyClass obj2 = new MyClass(10); // calls the parameterized constructor
        MyClass obj3 = new MyClass(obj2); // calls the copy constructor
    }
}